/*
 * drive.h
 *
 *  Created on: 10 janv. 2024
 *      Author: User
 */

#ifndef DRIVE_H_
#define DRIVE_H_

#define RIGHT_SENSOR 6
#define OBSTACLE_SENSOR 4
#define LEFT_SENSOR 0
#define RIGHT_SENSOR_BACK 2
#define LEFT_SENSOR_BACK 1
#define SENSOR_ERROR_VALUE 30 // diff�rence tol�rable entre les valeurs initiales des capteurs et les valeurs mesur�es lors du parcours
#define MOVE_FORWARD 'F'
#define BACK_FORWARD 'B'
#define SECURITY_DISTANCE 500


int right_sensor_init_value, left_sensor_init_value, distance;// valeurs analogiques de r�f�rence pour le suivi de la ligne blanche et d�tection d'obstacle
int right_sensor_value, left_sensor_value, right_sensor_back_value, left_sensor_back_value;// variables ayant les valeurs analogiques des capteurs durant le parcours du robot
char direction_order;
//char detection_order = 'O';

/*
 * fonction pour initialiser les valeurs de r�ference des capteurs du robot moteur
 */
void init_sensor_detection();

/*
 *
 */
void sensor_state();

/*
 *
 */
void sensor_detection();

/*
 *
 */
void robot_drive();

void update_direction_order( char* order);

void detect_obstacle();

//void update_detection();

#endif /* DRIVE_H_ */
