
#include "command.h"

#define GO_FORWARD 'F'
#define GO_BACK 'B'

char step = 'O', state = 'I', order, bool='A';

/**
 * main.c
 */
void main(void)
{
     robot_go();

    while(state != 'O')
    {

        update_state(&state);
        update_step( &step);
        switch(step)
        {
            case 'A':

                if(bool == 'A')
                {
                    init_robot();
                    bool ='B';
                }

                order = GO_BACK;//GO_FORWARD;
                update_direction( &order );
                //move_forward();

                break;

            case 'B':

                order = GO_BACK;
                //back_forward();
                update_direction( &order );
                break;

            case 'C':

                order = GO_BACK;//GO_FORWARD;
                //move_forward();
                update_direction( &order );
                break;

            case 'D':

                robot_stop();
                break;

        }
        driving();
    }



}



