/*
 * drive.c
 *
 *  Created on: 10 janv. 2024
 *      Author: User
 */
#include <msp430.h>

#include "command.h"
#include "ADC.h"
#include "drive.h"
//#include "timer_value.h"





void init_sensor_detection()
{
    P1DIR &= ~(BIT0 | BIT1 | BIT2 | BIT6 |BIT4);// initialisation des port 0, 1, 2, 6 et 4 du registre 1 comme entr�es
    P1REN &= ~(BIT0 | BIT1 | BIT2 | BIT6);// resistance de tirage
    P1REN |= BIT4;
    P1SEL &= ~(BIT0 | BIT1 | BIT2 | BIT6 | BIT4);
    P1SEL2 &= ~(BIT0 | BIT1 | BIT2 | BIT6 | BIT4);
    ADC_init();
    ADC_Demarrer_conversion( RIGHT_SENSOR );
    right_sensor_init_value = ADC_Lire_resultat ();
    /*ADC_init();
    ADC_Demarrer_conversion( MIDDLE_SENSOR );
    middle_sensor_init_value = ADC_Lire_resultat ();*/
    ADC_init();
    ADC_Demarrer_conversion( LEFT_SENSOR );
    left_sensor_init_value = ADC_Lire_resultat ();
}

void sensor_state()
{
    if( /*(*/ (right_sensor_init_value - SENSOR_ERROR_VALUE)<right_sensor_value /*) && ((right_sensor_init_value + SENSOR_ERROR_VALUE)<right_sensor_value)*/ )
        right_sensor_value = right_sensor_init_value;
    else
        right_sensor_value = -1;

    if( /*(*/ (left_sensor_init_value - SENSOR_ERROR_VALUE)<left_sensor_value /*) && ((left_sensor_init_value + SENSOR_ERROR_VALUE)<left_sensor_value)*/ )
        left_sensor_value = left_sensor_init_value;
    else
        left_sensor_value = -1;
    if( /*(*/ (right_sensor_init_value - SENSOR_ERROR_VALUE)<right_sensor_back_value /*) && ((right_sensor_init_value + SENSOR_ERROR_VALUE)<right_sensor_value)*/ )
            right_sensor_back_value = right_sensor_init_value;
    else
        right_sensor_back_value = -1;

    if( /*(*/ (left_sensor_init_value - SENSOR_ERROR_VALUE)<left_sensor_back_value /*) && ((left_sensor_init_value + SENSOR_ERROR_VALUE)<left_sensor_value)*/ )
        left_sensor_back_value = left_sensor_init_value;
    else
        left_sensor_back_value = -1;

    /*if( ( (middle_sensor_init_value - SENSOR_ERROR_VALUE)>middle_sensor_value ) && ((middle_sensor_init_value + SENSOR_ERROR_VALUE)<middle_sensor_value) )
        middle_sensor_value = middle_sensor_init_value;
    else
        middle_sensor_value = -1;*/

}

void sensor_detection()
{
    ADC_init();
    ADC_Demarrer_conversion( RIGHT_SENSOR );
    right_sensor_value = ADC_Lire_resultat ();
    /*ADC_init();
    ADC_Demarrer_conversion( OBSTACLE_SENSOR );
    distance = ADC_Lire_resultat ();*/
    ADC_init();
    ADC_Demarrer_conversion( LEFT_SENSOR );
    left_sensor_value = ADC_Lire_resultat ();
    ADC_init();
    ADC_Demarrer_conversion( RIGHT_SENSOR_BACK );
    right_sensor_back_value = ADC_Lire_resultat ();
    ADC_init();
    ADC_Demarrer_conversion( LEFT_SENSOR_BACK );
    left_sensor_back_value = ADC_Lire_resultat ();

    sensor_state();
}

void robot_drive(char* detection_order)
{
    sensor_detection();
    if(*detection_order == 'I')
        //detect_obstacle();

    if(direction_order == MOVE_FORWARD)//move forward
    {

        if((right_sensor_value == right_sensor_init_value)&&(left_sensor_value == left_sensor_init_value))
            move_forward();
        /*if((right_sensor_value == -1)&&(left_sensor_value == -1))
            back_forward();*/
        if((right_sensor_value == -1)&&(left_sensor_value == left_sensor_init_value))
        {
            turn_right();
            /*while((right_sensor_value == -1)&&(left_sensor_value == left_sensor_init_value))
            {

                ADC_init();
                ADC_Demarrer_conversion( RIGHT_SENSOR );
                right_sensor_value = ADC_Lire_resultat ();
                ADC_init();
                ADC_Demarrer_conversion( LEFT_SENSOR );
                left_sensor_value = ADC_Lire_resultat ();
                sensor_state();

            }
            move_forward();*/

        }
        if((left_sensor_value == -1)&&(right_sensor_value == right_sensor_init_value))
        {
            turn_left();
            /*while((right_sensor_value == -1)&&(left_sensor_value == left_sensor_init_value))
            {

                ADC_init();
                ADC_Demarrer_conversion( RIGHT_SENSOR );
                right_sensor_value = ADC_Lire_resultat ();
                ADC_init();
                ADC_Demarrer_conversion( LEFT_SENSOR );
                left_sensor_value = ADC_Lire_resultat ();
                sensor_state();

            }
            move_forward();*/


        }

    }
    if(direction_order == BACK_FORWARD)//back forward
    {

        if((right_sensor_back_value == right_sensor_init_value)&&(left_sensor_back_value == left_sensor_init_value))
            back_forward();
        /*if((right_sensor_value == -1)&&(left_sensor_value == -1))
            move_forward();*/
        if((right_sensor_back_value == -1)&&(left_sensor_back_value == left_sensor_init_value))
        {

            turn_left();
            //__delay_cycles(5000);
        }

        if((left_sensor_back_value == -1)&&(right_sensor_back_value == right_sensor_init_value))
        {

            turn_right();
            //__delay_cycles(5000);
        }

    }
}

void update_direction_order( char* order)
{
    direction_order = *order;
}

void detect_obstacle()
{

    if((distance > SECURITY_DISTANCE) && (direction_order == MOVE_FORWARD) )
    {
        //d�sactivation de la PWN des moteurs
        TA1CCTL1 |= OUTMOD_2;
        TA1CCTL2 |= OUTMOD_2;
    }

    else if (distance < SECURITY_DISTANCE)
    {
        //activation de la PWN des moteurs
        TA1CCTL1 |= OUTMOD_7;
        TA1CCTL2 |= OUTMOD_7;
        //P2DIR |= (BIT2|BIT4);
    }

    /*P1SEL &= ~BIT3; // fonction entree/sortie sur P1.3 (TA0.CCI0A)
    P1SEL2 &= ~BIT3; // fonction entree/sortie sur P1.3 (TA0.CCI0A)
    P1DIR |= BIT3;// P1.3 converti en sortie*/

}

/*void update_detection(char* detecting)
{
    detection_order = *detecting;

}*/


