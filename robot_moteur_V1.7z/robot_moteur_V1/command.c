/*
 * command.c
 *
 *  Created on: 9 janv. 2024
 *      Author: User
 */

#include <msp430.h>
#include "command.h"
#include "ADC.h"
#include "drive.h"
//#include "timer_value.h"

#define POWER_MAX 100
#define TIMER_COUNT 625 //valeur du compteur TACCR0 pour compter 10 millisecondes

int counter_10_millis = 0;//< compteur de chaque 10 millisecondes
//int time_diff = 0;
int time_pulse_diff = 0, init_counter_10_millis, continuous_counter_10_millis = 0, distance;
char rotation_speed;// variable d'odre de rotation_speed du robot
char level = 'O';// variable de verification de l'etape du robot
int time_counter = 0;//< compteur de chaque seconde
char statement = 'O';// variable d'etat du bouton de lancement du robot
char direction, detection = 'O';

void launch_robot()
{
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

    P1REN |= BIT3; // activation r�sistance interne
    P1OUT |= BIT3; // mode pull-up
    P1IE |= BIT3; // initialisation de l'interruption
    P1IES &= ~BIT3; // interruption sur front montant
    // donc appui car bouton connecte a la masse
    P1IFG &= ~(BIT3); // RAZ flag d�interruption
    __enable_interrupt(); // activation g�n�rale des interruptions

     while( statement == 'O')// attente de l'appui sur P1.3
    {

    }

}
void init_robot_timer()
{
    BCSCTL1= CALBC1_1MHZ; //frequence d�horloge 1MHz
    DCOCTL= CALDCO_1MHZ; //
    TA0CTL = 0|(TASSEL_2 | ID_3); //source SMCLK, pas de predivision ID_3 : 8
    TA0CTL |= MC_3; //comptage en mode up/down
    TA0CTL |= TAIE; //autorisation interruption TAIE
    TA0CCR0 = TIMER_COUNT;
}

void init_robot()
{
    /* configuration des outils moteurs */

    P2DIR |= (BIT2 | BIT4);// initialisation PWN moteur A et B
    P2DIR |= (BIT1 | BIT5);// sens de rotation des roues A et B
    P2DIR &= ~(BIT0 | BIT3);// opto-coupleurs A et B
    P2REN |= (BIT0 | BIT3); // r�sistances de tirage pour les encodeurs de A et B

    /* configuration du sens de rotation des moteurs */

    P2OUT |= BIT5;// sens de rotation des roues B
    P2OUT &= ~( BIT1 );// sens de rotation des roues A

    /* configuration en mode primaire des broches P2.2 et P2.4 pour g�nerer la PWN */

    P2SEL |= BIT2; // selection fonction TA1.1
    P2SEL2 &= ~BIT2; // selection fonction TA1.1
    P2SEL |= BIT4; // selection fonction TA1.2
    P2SEL2 &= ~BIT4; // selection fonction TA1.2

    // param�metre de temps de gestion pour la PWN


    TA1CTL = TASSEL_2 | MC_1; // source SMCLK pour TimerA , mode comptage Up
    TA1CCTL1 |= OUTMOD_7; // activation mode de sortie n�7 sur TA0.1
    TA1CCTL2 |= OUTMOD_7; // activation mode de sortie n�7 sur TA0.2

    TA1CCR0 = POWER_MAX; // determine la periode du signal
    TA1CCR1 = (POWER_MAX * 60)/100; // determine le rapport cyclique du signal TA0.1
    TA1CCR2 = (POWER_MAX * 60)/100; // determine le rapport cyclique du signal TA0.2

    /* configuration des param�tres pour l'usage du capteur ultrason */

    //TA0CCTL0 |= CM_3 | CCIS_0; // front montant + CCI0A
    //TA0CCTL0 |= CAP | CCIE; // mode capture + autorisation interruption

    //step = 'A';

}

void robot_stop()
{

    P2DIR &= ~(BIT2|BIT4);
    //TA1CCR0 = 0;// blocage de la PWN moteur A et B
    //TA1CCR1 = 0; // determine le rapport cyclique du signal TA0.1
    //TA1CCR2 = 0; // determine le rapport cyclique du signal TA0.2
}

void move_forward()
{

    power_up();
    P2OUT |= BIT5;// sens de rotation des roues B
    P2OUT &= ~( BIT1 );// sens de rotation des roues A

}

void back_forward()
{

    power_up();
    P2OUT &= ~( BIT5 );// sens de rotation des roues B
    P2OUT |=  BIT1 ;// sens de rotation des roues A

}

void turn_right(int slow)
{

    power_down();
    P2OUT &= ~( BIT5 | BIT1 );// sens de rotation des roues A et B
    //TA1CCR1 = (TA1CCR0 * 95)/100; // determine le rapport cyclique du signal TA0.1
    //TA1CCR2 = (TA1CCR0 * 95)/100; // determine le rapport cyclique du signal TA0.2


}

void turn_left()
{

    power_down();
    P2OUT |=  (BIT5 | BIT1) ;// sens de rotation des roues A et B
    //TA1CCR1 = (TA1CCR0 * 95)/100; // determine le rapport cyclique du signal TA0.1
    //TA1CCR2 = (TA1CCR0 * 95)/100; // determine le rapport cyclique du signal TA0.2

}

void power_down()
{
    TA1CCR0 = POWER_MAX; // determine la periode du signal
    TA1CCR1 = (POWER_MAX * 50)/100; // determine le rapport cyclique du signal TA0.1
    TA1CCR2 = (POWER_MAX * 50)/100; // determine le rapport cyclique du signal TA0.2
}

void power_up()
{
    TA1CCR0 = POWER_MAX; // determine la periode du signal
    TA1CCR1 = (POWER_MAX * 60)/100; // determine le rapport cyclique du signal TA0.1
    TA1CCR2 = (POWER_MAX * 60)/100; // determine le rapport cyclique du signal TA0.2
}

/*#pragma vector=TIMER0_A0_VECTOR
__interrupt  void sensor_ultra_sound()
{
    if(time_pulse_diff == 0)
    {
        init_counter_10_millis = continuous_counter_10_millis;
        time_pulse_diff = TACCR0;
        TA0CCTL0 &= ~CCIFG;
    }
    else if(continuous_counter_10_millis == init_counter_10_millis)
    {
        time_pulse_diff = TACCR0 - time_pulse_diff ;
        distance = (time_pulse_diff*16)/58;
        time_pulse_diff = 0;
        TA0CCTL0 &= ~CCIFG;
    }
    else if((continuous_counter_10_millis - init_counter_10_millis) == 1)
    {
        time_pulse_diff = TACCR0 + (TIMER_COUNT - time_pulse_diff) ;
        distance = (time_pulse_diff*16)/58;
        time_pulse_diff = 0;
        TA0CCTL0 &= ~CCIFG;
    }

}*/

#pragma vector=TIMER0_A1_VECTOR
__interrupt void course_timer()// compteur de temps en seconde et milliseconde
{
    //sensor_pulse_waves();
    counter_10_millis ++;
    continuous_counter_10_millis ++;
    /*if(counter_10_millis == 10)
    {


    }*/

    if(continuous_counter_10_millis == 25)
    {
        if(detection != 'I')
                detection = 'I';
        else
                detection = 'O';
        //update_detection(&detection);
        continuous_counter_10_millis = 0;
    }

    if(counter_10_millis == 100)
    {
        time_counter ++;// seconde �coul�
        counter_10_millis = 0;
        //time_diff = 0;

    }

    if((time_counter >= 5)&&(level == 'O'))
    {

        level = 'A';
        time_counter = 0;
        TA0CTL &= ~TAIFG; //RAZ TAIFG
    }

    if((time_counter >= 20)&&(level == 'A'))
    {

        level = 'B';
        time_counter = 0;
        TA0CTL &= ~TAIFG; //RAZ TAIFG
    }

    if((time_counter >= 5)&&(level == 'B'))
    {

        level = 'C';
        time_counter = 0;
        TA0CTL &= ~TAIFG; //RAZ TAIFG
    }

    if((time_counter >= 5)&&(level == 'C'))
    {
        level = 'D';
        time_counter = 0;
        statement = 'O';
        TA0CTL &= ~TAIFG; //RAZ TAIFG
    }


  TA0CTL &= ~TAIFG; //RAZ TAIFG
}

#pragma vector=PORT1_VECTOR
__interrupt void detect_launch(void)// intteruption due � l'appuie du bouton P1.3
{
    statement = 'I';
    P1IFG &= ~(BIT3); // RAZ flag d�interruption
}


void robot_go()
{

    launch_robot();
    init_robot_timer();
    init_sensor_detection();
    //robot_stop();
}

void update_step( char* step)
{
    *step = level;
}

void update_state( char* state)
{
    *state = statement;
}

void update_direction( char* order)
{
    direction = *order;
}

void driving()
{
    update_direction_order( &direction );
    robot_drive(&detection);
}


