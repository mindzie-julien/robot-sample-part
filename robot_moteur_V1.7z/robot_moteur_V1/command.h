/*
 * command.h
 *
 *  Created on: 9 janv. 2024
 *      Author: User
 */

#ifndef COMMAND_H_
#define COMMAND_H_



/*
 * fonction de d�marrage du robot
 */
void launch_robot();

/*
 * fonction pour d�marrer le timer du robot pour la gestion de la dur�e �coul�
 */
void init_robot_timer();

/*
 *fontion d'initialisation des param�tres du microcontroleur
 */
void init_robot();

/*
 * fonction pour faire arreter le robot
 */
void robot_stop();

/*
 * fonction pour faire avancer le robot
 */
void move_forward();

/*
 * fonction pour faire reculer le robot
 */
void back_forward();

/*
 * fonction pour d�marrer la rotation du robot vers le cot� gauche
 */
void turn_right();

/*
 * fonction pour d�marrer la rotation du robot vers le cot� droit
 */
void turn_left();

/*
 * fonction pour r�duire la PWN des moteurs afin de ralentir le robot
 */
void power_down();

/*
 * fonction pour augmenter la PWN des moteurs afin d'acc�lerer le robot
 */
void power_up();

/*
 * int�rruption pour d�tecter des obstacles
 */
void detect_obstacle();// interruption

/*
 * interruption pour la temporisation du parcours du robot
 */
void course_timer();// interruption, timer

/*
 * fonction pour executer l'etape initiale du robot
 */
void robot_go();

void update_step( char* step);

void update_state( char* state);

void update_direction( char* order);

void driving();

#endif /* COMMAND_H_ */
